//: Playground - noun: a place where people can play

import UIKit

class Graph : NSObject {
    
    //matrix represent the egdes
    var matrix = [[Int]]()
    var vertices = [Int]()
    var edges = [(Int, Int)]()
    
    init(vertices: [Int]) {
        super.init()
        self.vertices = vertices
        initiateMatrix(vertices: vertices)
    }
    
    init(vertices: [Int], edges: [(Int,Int)]){
        super.init()
        self.vertices = vertices
        self.edges = edges
        self.initiateMatrix(vertices: vertices)
        for e in edges {
            addEdge(vertexA: e.0, vertexB: e.1)
        }
    }
    
    func initiateMatrix(vertices: [Int]){
        matrix = Array<Any>(repeating: Array(repeating: 0, count: vertices.count), count: vertices.count) as! [[Int]]
        for i in 0...vertices.count-1 {
            for j in 0...vertices.count-1{
                matrix[i][j] = 0
            }
        }
    }
    
    func getIndex(for key: Int) -> Int? {
        for index in 0...vertices.count-1{
            if key == vertices[index] {
                return index
            }
        }
        return nil
    }
    
    func addVertix(vertix: Int){
        self.vertices.append(vertix)
        self.initiateMatrix(vertices: vertices)
        for e in edges {
            addEdge(vertexA: e.0, vertexB: e.1)
        }
    }
    
    func addEdge(vertexA: Int, vertexB: Int){
        guard let indexA = getIndex(for: vertexA) else {return}
        guard let indexB = getIndex(for: vertexB) else {return}
        
        if indexA == indexB{
            matrix[indexA][indexB] += 2
        }else{
            matrix[indexA][indexB] += 1
        }
    }
}

let vertices = [1,2,3,4,5,6]
let edges = [(1,1),(1,2),(1,5),(2,5),(2,1),(2,3),(5,1),(5,2),(5,4),(3,2),(3,4),(4,3),(4,5),(4,6),(6,4)]

var graph = Graph(vertices: vertices, edges: edges)
graph.addEdge(vertexA: 2, vertexB: 1)

for i in 0...graph.vertices.count-1 {
    for j in 0...graph.vertices.count-1{

        print(graph.matrix[i][j], separator: "", terminator: " ")
    }
    print()
}







